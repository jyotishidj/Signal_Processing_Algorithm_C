function A=lp_coeff(signal,N)

n=length(signal);
R=xcorr(signal);
k=R(n+1)/R(n);
a=-k;
k=(R(n+2)+a*R(n+1))/(R(n)+a*R(n+1));

for j=2:N
    for i=1:j
        if i==j
            a1(i)=-k;
        else
            a1(i)=a(i)-k*a(j-i);
        end
    end
    a=a1;
    num=0;din=0;
    for i=1:j
        num=num+a(i)*R(n+j+1-i);
        din=din+a(i)*R(n+i);
    end
    k=(R(n+j+1)+num)/(R(n)+din);
end
A=[1,a];   
