function spectrum = short_ft(frame,frame_shift,signal,window)
len = length(signal);
[k,t] = meshgrid(1:frame_shift:len-frame+1 , 1:frame);%creating meshgrid for 3d plot

[m,n] = size(k);
spectrum=zeros(frame,n);
if strcmp(window,'hamming')
    for i = 1:n
        sp_temp = signal(k(1,i):k(1,i)+frame-1).*(hamming(frame)); 
        spectrum(:,i)=(fftshift(fft(sp_temp)))';
    end
elseif strcmp(window,'hanning')
    for i = 1:n
        sp_temp = signal(k(1,i):k(1,i)+frame-1).*(hanning(frame)); 
        spectrum(:,i)=(fftshift(fft(sp_temp)))';
    end
else strcmp(window,'rectangular')
    for i = 1:n
        sp_temp = signal(k(1,i):k(1,i)+frame-1); 
        spectrum(:,i)=(fftshift(fft(sp_temp)))';
    end
end
surf(k,t,abs(spectrum));
