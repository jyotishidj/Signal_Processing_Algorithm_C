clc;
clear all;
[speech,Fs]=audioread('science.wav');
window_size1=input('Enter the size of window in ms:');
window_size=2^(floor(log2(floor(window_size1*(Fs/1000)))));
window_shift1=input('Enter the shift window in ms:');
window_shift=floor(window_shift1*(Fs/1000));
figure
stft1=short_ft(window_size,window_shift,speech,'hamming');
figure
stft2=short_ft(window_size,window_shift,speech,'hanning');
figure
stft3=short_ft(window_size,window_shift,speech,'rectangular');