function X=diffft(x)
n=length(x);
n1=log2(n);
if isinteger(n1)
    disp('ditfft cannot be calculated');
    return
end
X=zeros(1,n);
for a=n1:-1:1
    N=2^a;
    for k=1:n/N
        for s=1:N/2
            j=N*k-(N/2+s-1);
            x1=x(j);
            h=N*k-s+1;
            x2=x(h);
            x(j)=x1+x2;
            x(h)=(x1-x2)*exp(-1i*2*pi*((N/2)-s)/N);
        end
    end
end
for g=1:n
    X(bin2dec(fliplr(dec2bin(g-1,n1)))+1)=x(g);
end
end