clc;
clear all;
x=audioread('voice.wav');%samplinf frequency of voice is 48000
f1=6000;f2=8000;f3=10000;
t=0:1/48000:1-(1/48000);
for i=1:48000
    multitone(i)=0.02*sin(2*pi*f1*t(i))+0.1*sin(2*pi*f2*t(i))+0.08*sin(2*pi*f3*t(i));
end

noisy=x'+multitone;
plot(noisy);
sound(noisy,48000);pause(1)
%%
%filter design
N   = 80;        % FIR filter order
Fp  = 4000;       % 20 kHz passband-edge frequency
Fs  = 48000;       % 96 kHz sampling frequency
Rp  = 0.00057565; % Corresponds to 0.01 dB peak-to-peak ripple
Rst = 1e-4; 
coeff = firceqrip(N,Fp/(Fs/2),[Rp Rst],'passedge');

%%
%filtering
% coef=load('filtercoeff.mat');
% coeff=coef.filtercoeff;
filtered=overlap(noisy,coeff,48);
sound(filtered,48000);
figure
plot(filtered)


