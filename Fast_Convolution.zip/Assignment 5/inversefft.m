function X=inversefft(x11)
n=length(x11);
n1=log2(n);
if isinteger(n1)
    disp('ditfft cannot be calculated');
    X=0;
    return
end
x=zeros(1,n);
for g=1:n
    x(bin2dec(fliplr(dec2bin(g-1,n1)))+1)=x11(g);
end
for a=1:n1
    N=2^a;
    for k=1:n/N
        for s=1:N/2
            j=N*k-(N/2+s-1);
            x1=x(j);
            h=N*k-s+1;
            x2=x(h)*exp(1i*2*pi*((N/2)-s)/N);
            x(j)=0.5*(x1+x2);
            x(h)=0.5*(x1-x2);
        end
    end
end
X=real(x);
end