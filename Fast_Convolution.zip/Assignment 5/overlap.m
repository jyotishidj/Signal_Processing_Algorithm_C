function X=overlap(x,h,l)
%l should be such that it can divide length(x);
%l is the length of a lump of x;
m=length(h);
n=l+m-1;
k=floor(length(x)/l);
X=zeros(1,length(x)+m-1);
h=[h,zeros(1,l-1)];
H=ditfft(h);
for i=1:k
    x1=[x((i-1)*l+1:i*l),zeros(1,m-1)];
    X1=ditfft(x1);
    inte=X1.*H;
    inter=inversefft(inte);
    if i==1
        X(1:n)=inter;
    else
        X(((i-1)*l+1):((i-1)*l+n))= X(((i-1)*l+1):((i-1)*l+n))+inter;
    end
end
    
